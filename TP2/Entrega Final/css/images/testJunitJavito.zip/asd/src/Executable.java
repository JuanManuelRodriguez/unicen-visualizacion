public interface Executable {
public void Execute(Object obj);
public void Stop();
}