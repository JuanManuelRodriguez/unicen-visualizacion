import org.junit.runner.JUnitCore;


public class TestsRunner {

	 public static void main(String args[]) {
	        JUnitCore.runClasses(TestSuite.class);
	    }
	
}
